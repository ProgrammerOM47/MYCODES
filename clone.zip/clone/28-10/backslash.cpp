#include<iostream>
using namespace std;

int main(){
	cout<<"HelloWorld\n";
	cout<<"HelloifWorld\t"<<endl;
	cout<<"Hell\tWorld\t";
	cout<<"Hello World"<<endl;
	return 0;
}