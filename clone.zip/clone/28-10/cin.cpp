#include<iostream>
using namespace std;

int main(){
	int a = 1+8, b, c = 88+a, d;
	cout<<"a: "<<a<<" b: "<<b<<" c: "<<c<<" d: "<<d<<endl;
	cin>>a>>b>>c>>d;
	cout<<"a: "<<a<<" b: "<<b<<" c: "<<c<<" d: "<<d<<endl;
	return 0;
}