#include<iostream>
using namespace std;

int main(){
	// syntax 
	// data_type identifier;
	int a; // declaration
	// 1000
	cout<<a<<endl; // garbage value
	// 1000
	a = 10; // assignment
	cout<<a<<endl;

	int b = 5; // initialization
	cout<<b<<endl;
	return 0;
}