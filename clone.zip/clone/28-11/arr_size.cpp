#include<iostream>
using namespace std;
int main(){
	int arr[5] = {0};
	cout<<arr<<endl;
	cout<<arr+1<<endl;
	cout<<&arr<<endl;
	cout<<&arr+1<<endl;
	return 0;
}