#include<iostream>
using namespace std;
int main(){
	int p, r, t;
	cout<<"p: ";
	cin>>p;
	cout<<"r: ";
	cin>>r;
	cout<<"t: ";
	cin>>t;
	cout<<p*r*t/100.00000<<endl;
	// cout<<p*r*t/13.0<<endl;
	return 0;
}