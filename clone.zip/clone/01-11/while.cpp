#include<iostream>
using namespace std;
int main(){
	/* 
	initialize the counter // initialization
 	while(condition){      // condition check
		task
		update the counter // updation
	}
	*/
	int i = 1;
	while(i <= 100){
		cout<<i<<" ";
		i = i + 1;
	}
	cout<<endl;
	return 0;
}