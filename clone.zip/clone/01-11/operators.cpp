#include<iostream>
using namespace std;

int main(){
	int a = 10, b = 3;
	cout<<(a+b != a-b)<<endl;
	return 0;
}