#include<iostream>
#include<cstring>
using namespace std;
class c1{
public:
	int n1;
	int n2;
	c1(int n1, int){
		this.n1 = n1;
		this.n2 = n2;
	}	
};
int main(){
	c1 a(1, 2);
	return 0;
}