#include<iostream>
using namespace std;
#define pie (3.14 + 1)

int main(){
	cout<<pie<<endl;
	float circumference = 2 * pie * 7;
	cout<<circumference<<endl;
	return 0;
}