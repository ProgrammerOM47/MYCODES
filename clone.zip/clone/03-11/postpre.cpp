#include<iostream>
using namespace std;
int main(){
	int a = 0, b = 0;
	if(++b and a++){
		cout<<a<<endl;
		cout<<b<<endl;
	}
	cout<<a<<endl;
	cout<<b<<endl;
	return 0;
}