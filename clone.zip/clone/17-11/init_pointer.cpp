#include<iostream>
using namespace std;
int main(){
	int i;
	int *iptr = &i;
	cout<<iptr<<endl;
	cout<<&i<<endl;
	return 0;
}