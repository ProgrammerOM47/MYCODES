#include<iostream>
#include<cstring>
using namespace std;
int main(){
	// string s = "Hello";
	// cout<<s<<endl;
	// getline(cin, s);
	// cout<<s<<endl;
	// int n;
	// cin>>n;
	// string s[100];
	// cout<<sizeof(s)<<endl;
	// cout<<sizeof(s[0])<<endl;
	// int size[n];
	string s;
	cout<<sizeof(s)<<endl;
	getline(cin, s);
	cout<<s<<endl;
	cout<<sizeof(s)<<endl;
	return 0;
}